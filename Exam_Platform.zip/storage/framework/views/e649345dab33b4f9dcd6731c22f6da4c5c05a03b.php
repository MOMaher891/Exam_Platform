
<?php $__env->startSection('title','Sign In'); ?>
<?php $__env->startSection('content'); ?>

<main class="main">

      <div class="">
        <div class="container">
          <div class="row">
            <div class="col">
              <div class="ugf-contact-wrap">
                <form class="row" enctype="multipart/form-data" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                  <div class="col-lg-5 offset-lg-3">
                    <h2>Login</h2>


                    <div class="form-group">
                      <label for="inputMail">Email Addresss</label>
                      <input type="email" class="form-control" id="inputMail" placeholder="e.g. example@mail.com" name="email"  value="<?php echo e(old('email')); ?>" required>
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger mt-2"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="inputTextarea">Password</label>
                      <input type="password" class="form-control" id="inputpassword" placeholder="ASDasd!@#123" name="password"  value="<?php echo e(old('password')); ?>" required>
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger mt-2"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn">SignUp</button>
                  </div>

                  <div class="col-lg-5 offset-lg-1">
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
    </div>
</main>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    var phone  =document.querySelector('#inputPhone');
    window.intlTelInput(phone,{});
</script>

<script>
    document.addEventListener('DOMContentLoaded', () => {

const selectDrop = document.querySelector('#countries');
// const selectDrop = document.getElementById('countries');


fetch('http://restcountries.eu/rest/v2/all').then(res => {
  return res.json();
}).then(data => {
  let output = "";
  data.forEach(country => {
    output += `

    <option value="${country.name}">${country.name}</option>`;
  })

  selectDrop.innerHTML = output;
}).catch(err => {
  console.log(err);
})


});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/website/login.blade.php ENDPATH**/ ?>