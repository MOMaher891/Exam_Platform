
<?php $__env->startSection('title', 'DashBoard'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Welcome</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/index.blade.php ENDPATH**/ ?>