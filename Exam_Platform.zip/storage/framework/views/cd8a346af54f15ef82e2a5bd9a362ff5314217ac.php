<?php switch($type):
    case ('action'): ?>
        <a href="<?php echo e(route('admin.staff.edit', $staff->id)); ?>" title="Edit" class="btn btn-secondary"><i class="fa fa-pen"></i></a>
        <a href="<?php echo e(route('admin.staff.delete', $staff->id)); ?>" title="Show Permissions" class="btn btn-danger"><i
                class="fa fa-trash"></i></a>
    <?php break; ?>

    <?php default: ?>
<?php endswitch; ?>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/staff/action.blade.php ENDPATH**/ ?>