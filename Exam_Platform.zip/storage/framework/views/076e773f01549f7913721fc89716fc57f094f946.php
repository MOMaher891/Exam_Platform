
<?php $__env->startSection('title', 'Add Quiz'); ?>

<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Add Quiz</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">DashBoard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.exam.index')); ?>">Quiz</a></li>
                        <li class="breadcrumb-item active">Add Quiz</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <form class="card-body" id="myForm" method="post" action="<?php echo e(route('admin.exam.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <h4 class="card-title">Add New Quiz</h4>
                    <p class="card-title-desc">Here are examples : You can add Quiz Programming on 23-8-2023</p>

                    <div class="row mb-3">
                        <div class="col-md-6 col-sm-12">
                            <label for="example-date-input" class="col-sm-2 col-form-label">Date</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="date" name="date" id="example-date-input"
                                    value="<?php echo e(old('date')); ?>" min="<?php $currentDate = new DateTime();
                                    // $currentDate->add(new DateInterval('P1D'));
                                    $nextDay = $currentDate->format('Y-m-d');

                                    echo $nextDay; ?>" required>
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger mt-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6 col-sm-12">
                            <label for="example-date-input" class="col-sm-3 col-form-label">Show date</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="date" name="show_date" id="example-date-input"
                                    value="<?php echo e(old('show_date')); ?>" min="<?php $currentDate = new DateTime();
                                    // $currentDate->add(new DateInterval('P1D'));
                                    $nextDay = $currentDate->format('Y-m-d');

                                    echo $nextDay; ?>" required>
                                <?php $__errorArgs = ['show_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger mt-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6 col-sm-12">
                            <label for="example-number-input" class="col-sm-2 col-form-label">Period price</label>
                            <div class="col-sm-10">
                                <input class="form-control" type="number" name="price" id="example-number-input"
                                    value="<?php echo e(old('price')); ?>" placeholder="Ex: 150 $" required>
                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger mt-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div>
                                <h5 class="font-size-14 mb-4">Type of Exam</h5>
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="radio" id="formCheck1" name="type" value="public"  onclick="hideCenters()">
                                    <label class="form-check-label" for="formCheck1">
                                        Public
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" id="formCheck1" name="type" value="private" onclick="ShowCenters()" >
                                    <label class="form-check-label" for="formCheck1">
                                        Private
                                    </label>
                                </div>
                            </div>
                        </div>
                        

                        <div class="col-md-12 d-none" id="Centers" >
                            <div class="card">
                                <div class="card-title">
                                    Choose Center
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                    <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4 bg-white">
                                            <div class="">
                                                <div class="checkbox checkbox-primary mb-2">
                                                    <input id="<?php echo e($center->id); ?>" type="checkbox"
                                                        value="<?php echo e($center->id); ?>" name="center_id[]" class="form-check-input" >
                                                    <label for="<?php echo e($center->id); ?>"><?php echo e($center->name); ?></label>
                                                </div>
                                            </div>
                                        </div> <!-- end col-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button type="submit" id="submit" class="btn btn-info waves-effect waves-light"
                        style="margin-top:20px">Save</button>
                    <a href="<?php echo e(route('admin.staff.index')); ?>" class="btn btn-light waves-effect"
                        style="margin-top:20px">Cancel</a>
                </form>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function ShowCenters()
    {
        $("#Centers").removeClass('d-none')
    }
</script>
<script>
function hideCenters()
    {
        $("#Centers").addClass('d-none')
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/exam/create.blade.php ENDPATH**/ ?>