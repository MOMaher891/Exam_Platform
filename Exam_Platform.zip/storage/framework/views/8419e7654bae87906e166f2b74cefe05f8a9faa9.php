<?php $__env->startComponent('mail::message'); ?>
Your Verification Code is.
<?php $__env->startComponent('mail::button', ['url' => 'https://laraveltuts.com']); ?>
<?php echo e($code); ?>

<?php echo $__env->renderComponent(); ?>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/emails/reset_password.blade.php ENDPATH**/ ?>