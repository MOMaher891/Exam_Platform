

<?php $__env->startComponent('mail::message'); ?>
<?php echo e($subject); ?>

<?php $__env->startComponent('mail::button', ['url' => 'https://laraveltuts.com']); ?>
<?php echo e($body); ?>

<?php echo $__env->renderComponent(); ?>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/emails/accept_mail.blade.php ENDPATH**/ ?>