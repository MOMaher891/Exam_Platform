
<?php $__env->startComponent('mail::message'); ?>
#<?php echo e($title); ?>

<br>
<?php echo e($body); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/emails/exam.blade.php ENDPATH**/ ?>