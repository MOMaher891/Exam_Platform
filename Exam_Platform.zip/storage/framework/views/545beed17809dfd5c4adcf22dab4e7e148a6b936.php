
<?php $__env->startSection('title', 'Inspector profile'); ?>
<?php $__env->startSection('content'); ?>
<style></style>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0">Inspector profile</h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">DashBoard</a></li>
                        </li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.inspector.index')); ?>">Inspector</a></li>
                        </li>
                        <li class="breadcrumb-item active"><?php echo e($inspector->name); ?></li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <form class="card-body" id="myForm" method="post" action="<?php echo e(route('admin.category.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <h4 class="card-title">Inspector profile <?php if($inspector->status == 'accept'): ?>
                        <span class="text-success" style="font-weight: bolder;font-size:18px">(Accepted)</span>
                    <?php elseif($inspector->status == 'cancel'): ?>
                        <span class="text-danger" style="font-weight: bolder;font-size:18px">(Rejected)</span>
                    <?php endif; ?></h4>
                    <?php if($inspector->status == 'pending'): ?>
                        <p class="card-title-desc">Here are examples : You can accept or cancel inspector </p>
                    <?php elseif($inspector->status == 'accept'): ?>
                        <p class="card-title-desc">Here are examples : You can reject inspector</p>
                    <?php else: ?>
                        <p class="card-title-desc">Here are examples : You can accept inspector</p>
                    <?php endif; ?>
                    <p class="card-title-desc text-danger" style="font-weight: bolder;font-size:16px">Note : Click on image to zoom it</p>

                    <div class="row mb-3">
                        <div class="col-md-4 col-lg-4 col-sm-12">
                            <img id="zoom-img_personal" src="<?php echo e(asset('uploads/inspector/personal/'.$inspector->img_personal)); ?>" width="270px" style="object-fit: contain;margin-left:20px;border-radius:20px;box-shadow:1px 1px 15px #CCC" alt="">
                        </div>
                        
                        <div class="col-md-6 col-lg-6 col-sm-12">
                            <label for="example-text-input" class="col-sm-2 col-form-label">Name</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->name); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->email); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">Phone</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->phone); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">Address</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->address); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">National ID</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->national_id); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">Nationality</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->nationality); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">Job title</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->job_title); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">Gender</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->gender); ?>" disabled>
                            </div>
                            <label for="example-text-input" class="col-sm-2 col-form-label">Birth date</label>
                            <div class="col-sm-10">
                                <input class="form-control"
                                    id="example-text-input" value="<?php echo e($inspector->birth_date); ?>" disabled>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-5 mb-3">
                        <h4>Attachments</h4>
                        <div class="col-md-3 col-lg-2 col-sm-12">
                            <img id="zoom-img_passport" src="<?php echo e(asset('uploads/inspector/passport/'.$inspector->img_passport)); ?>" width="100%" height="100%" style="object-fit: contain;border-radius:20px;box-shadow:1px 1px 15px #CCC" alt="">
                        </div>
                        <div class="col-md-3 col-lg-2 col-sm-12">
                            <img id="zoom-img_national_front" src="<?php echo e(asset('uploads/inspector/national/'.$inspector->img_national)); ?>" width="100%" height="100%" style="object-fit: contain;border-radius:20px;box-shadow:1px 1px 15px #CCC" alt="">
                        </div>
                        <div class="col-md-3 col-lg-2 col-sm-12">
                            <img id="zoom-img_national_back" src="<?php echo e(asset('uploads/inspector/national_back/'.$inspector->img_national_back)); ?>" width="100%" height="100%" style="object-fit: contain;border-radius:20px;box-shadow:1px 1px 15px #CCC" alt="">
                        </div>
                        <div class="col-md-3 col-lg-2 col-sm-12">
                            <img id="zoom-img_certificate" src="<?php echo e(asset('uploads/inspector/certificate/'.$inspector->img_certificate)); ?>" width="100%" height="100%" style="object-fit: contain;border-radius:20px;box-shadow:1px 1px 15px #CCC" alt="">
                        </div>
                        <div class="col-md-3 col-lg-2 col-sm-12">
                            <img id="zoom-img_certificate_good_conduct" src="<?php echo e(asset('uploads/inspector/certificate_good_conduct/'.$inspector->img_certificate_good_conduct)); ?>" width="100%" height="100%" style="object-fit: contain;border-radius:20px;box-shadow:1px 1px 15px #CCC" alt="">
                        </div>
                    </div>

                <?php if($inspector->status == 'pending'): ?>
            <a href="<?php echo e(route('admin.inspector.accept',$inspector->id)); ?>" class="btn btn-success waves-effect"
                style="margin-top:20px">Accept</a>
            
                <button type="button" class="btn btn-danger waves-effect" data-bs-toggle="modal" data-bs-target=".bs-example-modal-center">Reject</button>

                <?php elseif($inspector->status == 'accept'): ?>
                
                    <button type="button" class="btn btn-danger waves-effect" data-bs-toggle="modal" data-bs-target=".bs-example-modal-center">Reject</button>
            <a href="<?php echo e(route('admin.inspector.index')); ?>" class="btn btn-light waves-effect"
                style="margin-top:20px">Cancel</a>
                <?php else: ?>
                <a href="<?php echo e(route('admin.inspector.accept',$inspector->id)); ?>" class="btn btn-success waves-effect"
                    style="margin-top:20px">Accept</a>
            <a href="<?php echo e(route('admin.inspector.index')); ?>" class="btn btn-light waves-effect"
                style="margin-top:20px">Cancel</a>
                <?php endif; ?>

                </form>
            </div>
        </div> <!-- end col -->
    </div>




    
    <div class="modal fade bs-example-modal-center" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Reject Message</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                   <form action="<?php echo e(route('admin.inspector.reject')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($inspector->id); ?>">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="">Message Body</label>
                                <textarea name="reason" class="form-control" id="" cols="30" rows="10"></textarea>
                            </div>
                        </div>
                        <br>
                        <div class="col-md-12">
                            <input type="submit" class="btn btn-primary" value="Send">
                        </div>
                    </div>
                   </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
const img_personal = document.getElementById("zoom-img_personal");
const img_passport = document.getElementById("zoom-img_passport");
const img_national_front = document.getElementById("zoom-img_national_front");
const img_national_back = document.getElementById("zoom-img_national_back");
const img_certificate = document.getElementById("zoom-img_certificate");
const img_certificate_good_conduct = document.getElementById("zoom-img_certificate_good_conduct");


img_personal.addEventListener("click", () => {
    zoom(img_personal);
});
img_passport.addEventListener("click", () => {
    zoom(img_passport);
});
img_national_front.addEventListener("click", () => {
    zoom(img_national_front);
});
img_national_back.addEventListener("click", () => {
    zoom(img_national_back);
});
img_certificate.addEventListener("click", () => {
    zoom(img_certificate);
});
img_certificate_good_conduct.addEventListener("click", () => {
    zoom(img_certificate_good_conduct);
});



function zoom(image){
    if (image.requestFullscreen) {
        image.requestFullscreen();
    } else if (image.mozRequestFullScreen) {
        image.mozRequestFullScreen();
    } else if (image.webkitRequestFullscreen) {
        image.webkitRequestFullscreen();
    } else if (image.msRequestFullscreen) {
        image.msRequestFullscreen();
    }
}
</script>

<script>
    $(document).ready(function() {
    $("#accept").click(function() {
        $.ajax({
            url: "", // Change to your server-side script URL
            method: "GET",   // Change to the appropriate HTTP method
            success: function(response) {
                $("#result").html(response);
            },
            error: function(xhr, status, error) {
                console.error("AJAX request error:", error);
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/inspector/show.blade.php ENDPATH**/ ?>