<?php switch($type):
    case ('action'): ?>
        <a href="<?php echo e(route('admin.exam_times.create', $data->id)); ?>" title="Apply in Exam" class="btn btn-primary"><i class="fa fa-plus"></i></a>
    <?php break; ?>
    <?php default: ?>
<?php endswitch; ?>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/exam_times/action.blade.php ENDPATH**/ ?>