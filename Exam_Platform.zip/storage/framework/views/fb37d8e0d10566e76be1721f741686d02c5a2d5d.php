<?php switch($type):
    case ('action'): ?>

        <?php if(auth()->user()->hasPermission('show_inspector')): ?>
        <a href="<?php echo e(route('admin.inspector.exam_observe', ['exam_id'=>$inspector->id])); ?>" title="Show Invigilator" class="btn btn-info"><i
            class="fa fa-eye"></i></a>
        <?php endif; ?>

    <?php break; ?>

    <?php default: ?>
<?php endswitch; ?>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/inspector/exam_action.blade.php ENDPATH**/ ?>