<?php switch($type):
    case ('action'): ?>
        <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" title="Edit" class="btn btn-secondary"><i
                class="fa fa-pen"></i></a>
        <button title="Show Permissions" data-id="<?php echo e($category->id); ?>" class="btn btn-danger delete-btn"><i class="fa fa-trash"></i>
        </button>
    <?php break; ?>

    <?php default: ?>
<?php endswitch; ?>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/category/action.blade.php ENDPATH**/ ?>