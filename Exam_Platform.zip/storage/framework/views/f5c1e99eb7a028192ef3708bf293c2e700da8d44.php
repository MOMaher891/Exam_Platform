<?php switch($type):
    case ('action'): ?>
        <a href="<?php echo e(route('permission.edit',$role->id)); ?>" title="Show Permissions" class="btn btn-info"><i class="fa fa-eye"></i></a>
        <a href="<?php echo e(route('role.edit',$role->id)); ?>" title="Edit" class="btn btn-secondary"><i class="fa fa-pen"></i></a>
        <?php break; ?>

    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/roles/action.blade.php ENDPATH**/ ?>