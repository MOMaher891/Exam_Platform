<?php switch($type):
    case ('action'): ?>
        <?php if(auth()->user()->hasPermission('edit_exam')): ?>
            <a href="<?php echo e(route('admin.exam.edit', $exam->id)); ?>" title="Edit" class="btn btn-secondary"><i class="fa fa-pen"></i></a>
            <button title="Show Permissions" data-id="<?php echo e($exam->id); ?>" class="btn btn-danger delete-btn"><i class="fa fa-trash"></i>
            </button>
        <?php endif; ?>
        <?php if(auth()->user()->hasRole('analyst') || auth()->user()->hasRole('superadmin')): ?>
        <?php if($exam->paid == 0): ?>
        <button title="Pay" data-id="<?php echo e($exam->id); ?>" class="btn btn-warning paid-btn">
            Pay
        </button>
            <?php else: ?>
            <button class="btn btn-success">
                Paid
            </button>
            <?php endif; ?>
        <?php endif; ?>
    <?php break; ?>

    <?php case ('status'): ?>
        <?php if($status == 0): ?>
            <p class="btn btn-warning">Active</p>
        <?php elseif($status == 1): ?>
            <p class="btn btn-info">Pending</p>
        <?php else: ?>
            <p class="btn btn-danger">Expire</p>
        <?php endif; ?>
    <?php break; ?>
    <?php case ('type'): ?>
        <?php if($data->type == 'public'): ?>
            <p class="btn btn-sm btn-primary">Access To All Centers</p>
        <?php else: ?>
            <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($d->name); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php break; ?>
    <?php case ('centers'): ?>
            <a href="<?php echo e(route('admin.exam.centers_show',['exam_id'=>$exam->id])); ?>">Centers</a>
    <?php break; ?>
    <?php case ('shift'): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span><?php echo e($d->shift); ?> ,</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php break; ?>
    <?php case ('Invigilator'): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span><?php echo e($d->num_of_observe); ?> ,</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php break; ?>
    <?php case ('attendance'): ?>
    <a href="<?php echo e(route('admin.exam.attendance_show',['exam_id'=>$exam->id])); ?>">Attendance</a>
    <?php break; ?>
    <?php case ('attend'): ?>
        <?php if($data->is_come == 0 ): ?>
            <span class="text-danger" style="font-weight:bolder">Not Attend</span>
        <?php else: ?>
            <span class="text-success" style="font-weight:bolder">Attend</span>

        <?php endif; ?>
    <?php break; ?>
    <?php default: ?>
<?php endswitch; ?>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/exam/action.blade.php ENDPATH**/ ?>