<style>
    .badge {
        position: absolute !important;
        right: 45px !important;
    }
</style>
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!-- User details -->
        <div class="user-profile text-center mt-3">
            <div class="">
                <img src="<?php echo e(asset('assets/images/users/person.jpg')); ?>" alt="" class="avatar-md rounded-circle">
            </div>
            <div class="mt-3">
                <h4 class="font-size-16 mb-1">
                    <?php if(Auth::guard()->user()->hasRole('admin')): ?>
                    <?php
                        $center = App\Models\Center::select('name')->where('user_id', Auth::guard()->user()->id)->first();
                    ?>
                    <?php echo e($center->name); ?>

                    <?php else: ?>
                        <?php echo e(Auth::guard()->user()->name); ?>

                    <?php endif; ?>
                </h4>
                <span class="text-muted"><i class="ri-record-circle-line align-middle font-size-14 text-success"></i>
                    Online</span>
            </div>
        </div>

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="<?php echo e(route('admin')); ?>" class="waves-effect">
                        <i class="ri-home-2-line"></i>
                        <span>Dashboard</span>
                    </a>
                </li>


                <?php if(auth()->user()->hasPermission('show_roles')): ?>
                    <li>
                        <a href="<?php echo e(route('role.index')); ?>" class=" waves-effect">
                            <?php if(App\Models\Role::count() != 0): ?>
                                <span
                                    class="badge rounded-pill bg-success float-end"><?php echo e(App\Models\Role::count()); ?></span>
                            <?php endif; ?>
                            <i class="ri-calendar-2-line"></i>
                            <span>Roles</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(auth()->user()->hasPermission('show_staff')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <?php if(App\Models\User::count() - 1 != 0): ?>
                                <span
                                    class="badge rounded-pill bg-success float-end"><?php echo e(App\Models\User::count() - 1); ?></span>
                            <?php endif; ?>

                            <i class="ri-user-3-line"></i>
                            <span>Staff</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('admin.staff.index')); ?>">Staff List</a></li>
                            <li><a href="<?php echo e(route('admin.staff.create')); ?>">Add Staff</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(auth()->user()->hasPermission('show_inspector')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <?php if(App\Models\Observe::count() != 0): ?>
                                <span
                                    class="badge rounded-pill bg-success float-end"><?php echo e(App\Models\Observe::count()); ?></span>
                            <?php endif; ?>

                            <i class="ri-user-3-line"></i>
                            <span>Invigilator</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('admin.inspector.index')); ?>">Invigilator List</a></li>
                            <?php if(auth()->user()->hasRole('admin')): ?>
                            <li><a href="<?php echo e(route('admin.inspector.inspector_center')); ?>">Invigilator in center</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(auth()->user()->hasRole('admin')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">

                            <i class="ri-layout-3-line"></i>
                            <span>Exams</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('admin.inspector.exams')); ?>">Exams List</a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if(auth()->user()->hasPermission('show_center')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <span
                                class="badge rounded-pill bg-success float-end"><?php echo e(App\Models\Center::count()); ?></span>
                            <i class="ri-user-3-line"></i>
                            <span>Centers</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <li><a href="<?php echo e(route('admin.center.index')); ?>">Center List</a></li>
                            <?php if(auth()->user()->hasPermission('add_center')): ?>
                            <li><a href="<?php echo e(route('admin.center.create')); ?>">Add Center</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>



                <?php if(auth()->user()->hasPermission('show_exam')): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <span
                            class="badge rounded-pill bg-success float-end"><?php echo e(App\Models\Exam::count()); ?></span>
                        <i class="ri-layout-3-line"></i>
                        <span>Quizes</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('admin.exam.index')); ?>">Quiz List</a></li>

                        <?php if(auth()->user()->hasPermission('add_exam')): ?>
                        <li><a href="<?php echo e(route('admin.exam.create')); ?>">Add quiz</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>



                <?php if( auth()->user()->hasRole('admin')): ?>
                    <li>
                        <a href="<?php echo e(route('admin.exam_times.index')); ?>" class=" waves-effect">
                            
                            <i class="ri-calendar-2-line"></i>
                            <span>Exam to Apply</span>
                        </a>
                    </li>
                <?php endif; ?>


            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/layouts/dashboard/sidebar.blade.php ENDPATH**/ ?>