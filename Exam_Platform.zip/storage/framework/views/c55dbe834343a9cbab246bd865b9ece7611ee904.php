<?php switch($type):
    case ('action'): ?>
        <a onclick="Apply(<?php echo e($data->id); ?>)" class="btn btn-primary"><i class="fa fa-check"></i></a>
        <?php break; ?>

    <?php default: ?>
        
<?php endswitch; ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/website/dashboard/exams/action.blade.php ENDPATH**/ ?>