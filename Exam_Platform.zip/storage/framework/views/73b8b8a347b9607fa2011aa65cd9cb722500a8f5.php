
<?php $__env->startSection('title','Sign Up'); ?>
<?php $__env->startSection('content'); ?>

<main class="main">

      <div class="">
        <div class="container">
          <div class="row">
            <div class="col">
              <div class="ugf-contact-wrap">
                <div class="card">
                  <?php if(session('success')): ?>
                  <h6 class="alert alert-success">
                      <?php echo e(session('success')); ?>

                  </h6>
                <?php endif; ?>               
               </div>
                <form class="row" enctype="multipart/form-data" method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                  <div class="col-lg-5 offset-lg-1">
                    <h2>Personal Info.</h2>

                    <div class="form-group">
                      <label for="inputText">Name</label>
                      <input type="text" class="form-control" id="inputText" placeholder="e.g. Robert Smith" name="name"  value="<?php echo e(old('name')); ?>" required>
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group ">
                        <label for="inputPhone">Phone</label>
                        <input type="tel" style="padding-left:52px !important" class=" form-control w-100" id="inputPhone" name="phone"  value="<?php echo e(old('phone')); ?>" required>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    <div class="form-group ">
                        <label for="inputPhone">Birth Date</label>
                        <input type="date" class=" form-control w-100" id="inputPhone" name="birth_date"  value="<?php echo e(old('birth_date')); ?>" required>
                        <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    
                    <div class="form-group ">
                        <label for="inputPhone">Job Title</label>
                        <input type="text" class=" form-control w-100" id="inputPhone" name="job_title" placeholder="Academic Coordinator"  value="<?php echo e(old('job_title')); ?>" required>
                        <?php $__errorArgs = ['job_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group ">
                        <label for="inputPhone">Emirates ID</label>
                        <input type="number" class=" form-control w-100" id="inputPhone" name="national_id"  value="<?php echo e(old('national_id')); ?>" required>
                        <?php $__errorArgs = ['national_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group ">
                        <label for="inputPhone">Gender</label>
                        <select name="gender" id="" class="form-control"  value="<?php echo e(old('gender')); ?>" required>
                            <option value="" disabled selected>Choose Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group ">
                        <label for="inputPhone">Nationality</label>
                        <input type="text" class=" form-control w-100" id="inputPhone" name="nationality" placeholder="Egyption"  value="<?php echo e(old('nationality')); ?>" required>
                        <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group ">
                        <label for="inputPhone">Address</label>
                        <input type="text" class=" form-control w-100" id="inputPhone" name="address" placeholder="Egypt/Cairo/Shubra"  value="<?php echo e(old('address')); ?>" required>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger mt-2"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="inputMail">Email Addresss</label>
                      <input type="email" class="form-control" id="inputMail" placeholder="e.g. example@mail.com" name="email"  value="<?php echo e(old('email')); ?>" required>
                      <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger mt-2"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="inputTextarea">Password</label>
                      <input type="password" class="form-control" id="inputPhone" placeholder="ASDasd!@#123" name="password"  value="<?php echo e(old('password')); ?>" required>
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger mt-2"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="inputTextarea">Confirm password</label>
                      <input type="password" class="form-control" id="inputPhone" name="confirm_password"  value="<?php echo e(old('confirm_password')); ?>" required>
                      <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger mt-2"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit" class="btn">SignUp</button>
                  </div>

                  <div class="col-lg-5 offset-lg-1">
                    <div class="contact-details">
                      <h2>Upload files.</h2>
                        <div class="form-group">
                          <label for="inputText">Personal Photo</label>
                          <input type="file" class="form-control" id="inputText" placeholder="e.g. Robert Smith" name="img_personal"  value="<?php echo e(old('img_personal')); ?>" required>
                          <?php $__errorArgs = ['img_personal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger mt-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-6">
                                <label for="inputPhone">Emirates ID front</label>
                                <input type="file" class=" form-control" id="inputPhone" name="img_national"  value="<?php echo e(old('img_national')); ?>" required>
                              <?php $__errorArgs = ['img_national'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="text-danger mt-2"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label for="inputPhone">Emirates ID back</label>
                                <input type="file" class=" form-control" id="inputPhone" name="img_national_back"  value="<?php echo e(old('img_national')); ?>" required>
                              <?php $__errorArgs = ['img_national'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="text-danger mt-2"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <div class="form-group ">
                            <label for="inputPhone">Passport Photo</label>
                            <input type="file" class=" form-control" id="inputPhone" name="img_passport"  value="<?php echo e(old('img_passport')); ?>" required>
                          <?php $__errorArgs = ['img_passport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger mt-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group ">
                            <label for="inputPhone">Graduation certificate</label>
                            <input type="file" class=" form-control" id="inputPhone" name="img_certificate"  value="<?php echo e(old('img_certificate')); ?>" required>
                          <?php $__errorArgs = ['img_certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger mt-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group ">
                            <label for="inputPhone">Police Clearance</label>
                            <input type="file" class=" form-control" id="inputPhone" name="img_certificate_good_conduct"  value="<?php echo e(old('img_certificate_good_conduct')); ?>" required>
                          <?php $__errorArgs = ['img_certificate_good_conduct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger mt-2"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <h2>Bank Info.</h2>
                        <div class="form-group ">
                            <label for="inputPhone">Bank Name</label>
                            <input type="text" class=" form-control w-100" id="inputPhone" name="bank_name" placeholder="CIB"  value="<?php echo e(old('job_title')); ?>" required>
                            <?php $__errorArgs = ['back_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mt-2"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group ">
                            <label for="inputPhone">IBAN</label>
                            <input type="text" class=" form-control w-100" id="inputPhone" name="IBAN" placeholder="EG:XXXXXXXX"  value="<?php echo e(old('IBAN')); ?>" required>
                            <?php $__errorArgs = ['IBAN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger mt-2"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
    </div>
</main>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
    var phone  =document.querySelector('#inputPhone');
    window.intlTelInput(phone,{});
</script>

<script>
    document.addEventListener('DOMContentLoaded', () => {

const selectDrop = document.querySelector('#countries');
// const selectDrop = document.getElementById('countries');


fetch('http://restcountries.eu/rest/v2/all').then(res => {
  return res.json();
}).then(data => {
  let output = "";
  data.forEach(country => {
    output += `

    <option value="${country.name}">${country.name}</option>`;
  })

  selectDrop.innerHTML = output;
}).catch(err => {
  console.log(err);
})


});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.website.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/website/register.blade.php ENDPATH**/ ?>