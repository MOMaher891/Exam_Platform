
<?php $__env->startSection('title', 'Quiz'); ?>
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                <h4 class="mb-sm-0"><?php echo e($exam->date); ?></h4>

                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin')); ?>">DashBoard</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.exam.index')); ?>">Exams</a></li>
                        </li>
                        <li class="breadcrumb-item active">Centers</li>
                    </ol>
                </div>

            </div>
        </div>
    </div>
    <!-- end page title -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Center List</h4>
                    <div class="text-center mb-3">
                    </div>
                    <div class="row w-100">
                        
                    <table id="datatable-buttons" class="table dt-responsive nowrap w-100">
                        <thead>
                            <tr>
                                <th>Center</th>
                                <th>Shift</th>
                                <th>Num Invigilator</th>
                                <th>Owner</th>
                                <?php if(auth()->user()->hasRole('superadmin') || auth()->user()->hasRole('analyst')): ?>
                                <th>Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>

                        <tbody>

                        </tbody>
                    </table>

                </div> <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        let DataTable = null
        function setDatatable() {
            let exam = <?php echo e($exam->id); ?>;
            var url = "<?php echo e(route('exam.center_data', ['exam_id' => ':exam'])); ?>";
            url = url.replace(':exam', exam);
            DataTable = $("#datatable-buttons").DataTable({
                processing: true,
                serverSide: true,
                dom: 'Blfrtip',
                lengthMenu: [5, 10, 20, 50, 100, 200, 500],
                pageLength: 9,
                sorting: [0, "DESC"],
                ordering: false,
                ajax: url,

                language: {
                    paginate: {
                        "previous": "<i class='mdi mdi-chevron-left'>",
                        "next": "<i class='mdi mdi-chevron-right'>"
                    },
                },


                columns: [
                    {
                        data: 'name'
                    },
                    {
                        data: 'shift'
                    },
                    {
                        data: 'Invigilator'
                    },
                    {
                        data: 'user.name'
                    },
                    {
                        data: 'action'
                    }
                ],
            });
        }

        setDatatable();

        // function handleFilter()
        // {
        //     status = $("#expire").val() || ''; // Expire or not
        //     type = $("#type").val() || ''; // public or private
        //     date_from = $("#date_from").val() || ''; // date from
        //     date_to = $("#date_to").val() || ''; //date to
        //     paid = $("#paid").val() || ''; //paid or not

        //     if(DataTable){
        //         url = "<?php echo e(route('exam.data')); ?>"+`?expire=${status}&type=${type}&date_from=${date_from}&date_to=${date_to}&paid=${paid}`;
        //         DataTable.ajax.url(url).load();
        //     }
        // }

        // function ClearFilter()
        // {
        //     status = $('#expire').val('');
        //     public = $("#public").val('');
        //     date_from = $("#date_from").val('');
        //     date_to = $("#date_to").val('');
        //     paid = $("#paid").val('');
        //     url = "<?php echo e(route('exam.data')); ?>";
        //     DataTable.ajax.url(url).load();

        // }
    </script>

    <script>
        //Delete Function
        $(document).on('click', '.delete-btn', function() {
            var exam_id = $(this).data('id');
            if (confirm("Are you sure you want to delete this quiz?")) {
                $.ajax({
                    type: "DELETE",
                    url: '/admin/exam/delete/' + exam_id,
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        $('#datatable-buttons').DataTable().ajax.reload();
                        toastr.success('Data deleted successfully!', 'success');
                    },
                    error: function(data) {
                        console.log('Error:', data);
                    }
                });
            }
        });

    </script>

    <script>
                $(document).on('click', '.paid-btn', function() {
            var exam_id = $(this).data('id');
            if (confirm("Are you sure you want to pay for this quiz?")) {
                $.ajax({
                    type: "POST",
                    url: '/admin/exam/payment/' + exam_id,
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>"
                    },
                    success: function(data) {
                        $('#datatable-buttons').DataTable().ajax.reload();
                        if(data['success']){
                            toastr.success(data['success']);
                        }
                        else if(data['error']){
                            toastr.error(data['error']);
                        }

                    },
                    error: function(data) {
                        toastr.error('errro','error');

                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/exam/centers.blade.php ENDPATH**/ ?>