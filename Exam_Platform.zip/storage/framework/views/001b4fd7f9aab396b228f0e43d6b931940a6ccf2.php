
<?php $__env->startSection('title', 'Page not found'); ?>
<?php $__env->startSection('content'); ?>

    <div class="card-body">
        <div class="ex-page-content text-center">
            <h1>404!</h1>
            <h3>Sorry, page not found</h3><br>

            <a class="btn btn-info mb-5 waves-effect waves-light" href="<?php echo e(route('admin')); ?>">Back to
                Dashboard</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/errors/404.blade.php ENDPATH**/ ?>