<?php switch($type):
    case ('action'): ?>
    <?php if(auth()->user()->hasRole('superadmin') || auth()->user()->hasRole('analyst')): ?>
        <a href="<?php echo e(route('admin.inspector.all_exams', $inspector->id)); ?>" title="Show Exams" class="btn btn-secondary"><i
                class="fa fa-newspaper"></i></a>
        <?php endif; ?>
        <?php if(auth()->user()->hasPermission('show_inspector')): ?>
        <a href="<?php echo e(route('admin.inspector.show', $inspector->id)); ?>" title="Show" class="btn btn-info"><i
            class="fa fa-eye"></i></a>
        <?php endif; ?>

        <?php if(auth()->user()->hasRole('admin')): ?>
            <?php if($inspector->black_list != null): ?>
            <a href="<?php echo e(route('admin.inspector.block', $inspector->id)); ?>" title="Unblock" class="btn btn-primary"><i
                class="fa fa-lock-open"></i></a>
            <?php else: ?>
            <a href="<?php echo e(route('admin.inspector.block', $inspector->id)); ?>" title="block" class="btn btn-danger"><i
                class="fa fa-lock"></i></a>
            <?php endif; ?>
        <?php endif; ?>


        <?php if(auth()->user()->hasPermission('delete_inspector')): ?>
                <button title="Delete inspector" data-id="<?php echo e($inspector->id); ?>" class="btn btn-danger delete-btn"><i class="fa fa-trash"></i>
                </button>
            <?php endif; ?>
    <?php break; ?>
    <?php case ('status'): ?>
    <?php if($inspector->status == 'pending'): ?>
    <p class="btn btn-warning">pending</p>
    <?php elseif($inspector->status == 'accept'): ?>
        <p class="btn btn-info">Accept</p>
    <?php else: ?>
        <p class="btn btn-danger">Cencel</p>
    <?php endif; ?>
    <?php break; ?>

    <?php default: ?>
<?php endswitch; ?>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/inspector/action.blade.php ENDPATH**/ ?>