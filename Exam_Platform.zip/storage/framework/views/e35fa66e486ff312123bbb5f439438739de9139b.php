<?php echo e($slot); ?>

<?php /**PATH F:\ExamSystem\Exam_Platform\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>