<?php switch($type):
    case ('attendance'): ?>
    <a href="<?php echo e(route('admin.center.inspector_for_exam_show',['exam_time_id'=>$data->id])); ?>">Attendance</a>
    <?php break; ?>
    <?php default: ?>
<?php endswitch; ?>
<?php /**PATH F:\ExamSystem\Exam_Platform\resources\views/dashboard/centers/exam_action.blade.php ENDPATH**/ ?>