@extends('layouts.website.dashboard.layout')
@section('title', 'DashBoard')
@section('content')
    <h1>Welcome</h1>
@endsection
